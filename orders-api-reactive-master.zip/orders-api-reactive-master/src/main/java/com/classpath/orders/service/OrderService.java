package com.classpath.orders.service;

import org.springframework.cloud.stream.messaging.Source;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.classpath.orders.dao.OrderDAO;
import com.classpath.orders.model.Order;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class OrderService {
	
	private final OrderDAO orderDAO;
	private final Source source;
	
	
	public Mono<Order> saveOrder(Order order) {
		Mono<Order> savedOrder = this.orderDAO.saveOrder(order);
		savedOrder.subscribe(o -> {
			Message<Order> orderMessage = MessageBuilder.withPayload(o).build();
			System.out.println("Sending messages to kafka broker ::::" );
			this.source.output().send(orderMessage);
		});
		return savedOrder;
	}
	
	public Flux<Order> fetchAllOrders(){
		return this.orderDAO.fetchAllOrders();
	}
	
	public Mono<Order> findOrderByOrderId(long id) {
		return this.orderDAO
				   .fetchOrderById(id);
	}
	
	public Mono<Void> deleteOrderById(long orderId) {
		return this.orderDAO.deleteOrderById(orderId);
	}
}
